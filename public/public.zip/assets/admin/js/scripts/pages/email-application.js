//  Notifications & messages scrollable
if($('#users-list').length > 0){
    $('#users-list').perfectScrollbar({
        theme:"dark"
    });
}